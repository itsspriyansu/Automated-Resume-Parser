from extractor import extract_text_from_pdf, parse_resume, extract_skills_and_education, extract_contact_info
from db import insert_into_db

def process_resume(filepath):
    text = extract_text_from_pdf(filepath)
    base_info = parse_resume(text)
    other_info = extract_skills_and_education(text)
    contact_info = extract_contact_info(text)
    resume_data = {**base_info, **other_info, **contact_info}
    insert_into_db(resume_data)
    return resume_data