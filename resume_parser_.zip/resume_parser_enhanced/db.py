import psycopg2

def insert_into_db(data):
    conn = psycopg2.connect(
        dbname="resume_db",
        user="postgres",
        password="pass",
        host="localhost",
        port="5432"
    )
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS candidates (
            id SERIAL PRIMARY KEY,
            name TEXT,
            email TEXT,
            phone TEXT,
            skills TEXT[],
            education TEXT[]
        );
    """)
    cursor.execute("""
        INSERT INTO candidates (name, email, phone, skills, education)
        VALUES (%s, %s, %s, %s, %s);
    """, (data['name'], data['email'], data['phone'], data['skills'], data['education']))
    conn.commit()
    cursor.close()
    conn.close()
