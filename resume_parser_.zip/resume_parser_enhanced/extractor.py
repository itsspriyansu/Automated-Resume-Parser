import pdfplumber
import spacy
import re

nlp = spacy.load('en_core_web_sm')

SKILLS = ["Python", "Java", "SQL", "Flask", "PostgreSQL"]
EDU_KEYWORDS = ["Bachelor", "Master", "B.Sc", "M.Sc", "B.Tech", "M.Tech"]

def extract_text_from_pdf(pdf_path):
    text = ''
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + '\n'
    return text

def parse_resume(text):
    doc = nlp(text)
    names = [ent.text for ent in doc.ents if ent.label_ == "PERSON"]
    return {"name": names[0].split("\n")[0] if names else "N/A", "text": text}

def extract_skills_and_education(text):
    skills_found = [skill for skill in SKILLS if skill.lower() in text.lower()]
    education = [line for line in text.split('\n') if any(kw in line for kw in EDU_KEYWORDS)]
    return {"skills": skills_found, "education": education}

def extract_contact_info(text):
    email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)
    phone_match = re.search(r'(\+91[-\s]?)?[0]?[789]\d{9}', text)
    return {
        "email": email_match.group(0) if email_match else "N/A",
        "phone": phone_match.group(0) if phone_match else "N/A"
    }