from flask import Flask, request, render_template_string
import os
from parser import process_resume

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

UPLOAD_FORM_HTML = '''
<!DOCTYPE html>
<html>
<head>
    <title>Resume Uploader</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f4f4f4; }
        h2 { color: #333; }
        form { background: white; padding: 20px; border-radius: 8px; max-width: 400px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        input[type="file"], input[type="submit"] { display: block; width: 100%; margin: 10px 0; padding: 10px; }
        input[type="submit"] { background-color: #28a745; color: white; border: none; border-radius: 4px; }
    </style>
</head>
<body>
    <h2>Upload Your Resume</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="resume" required />
        <input type="submit" value="Upload" />
    </form>
</body>
</html>
'''

RESULT_HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Resume Parsed</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f4f4f4; }
        h2 { color: #333; }
        ul { background: white; padding: 20px; border-radius: 8px; max-width: 600px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        li { margin-bottom: 10px; }
        a { display: inline-block; margin-top: 20px; text-decoration: none; color: #007bff; }
    </style>
</head>
<body>
    <h2>Resume Parsed Successfully</h2>
    <ul>
        <li><strong>Name:</strong> {{ name }}</li>
        <li><strong>Email:</strong> {{ email }}</li>
        <li><strong>Phone:</strong> {{ phone }}</li>
        <li><strong>Skills:</strong> {{ skills }}</li>
        <li><strong>Education:</strong><br> {{ education }}</li>
    </ul>
    <a href="/upload">Upload Another Resume</a>
</body>
</html>
'''

@app.route('/upload', methods=['GET', 'POST'])
def upload_resume():
    if request.method == 'GET':
        return UPLOAD_FORM_HTML

    if 'resume' not in request.files:
        return '<p>No file part</p>', 400

    file = request.files['resume']
    if file.filename == '':
        return '<p>No selected file</p>', 400

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    result = process_resume(filepath)

    return render_template_string(RESULT_HTML_TEMPLATE,
                                  name=result['name'],
                                  email=result['email'],
                                  phone=result['phone'],
                                  skills=', '.join(result['skills']),
                                  education='<br>'.join(result['education']))

if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True)
